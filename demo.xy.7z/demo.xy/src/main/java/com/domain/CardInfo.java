package com.domain;

public class CardInfo {

	private Long cardNo;
	private String identity;
	private String company;
	private String name;
	private String mobile;
	private String status;
	private String createDate;
	public Long getCardNo() {
		return cardNo;
	}
	public void setCardNo(Long cardNo) {
		this.cardNo = cardNo;
	}
	public String getIdentity() {
		return identity;
	}
	public void setIdentity(String identity) {
		this.identity = identity;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getCreateDate() {
		return createDate;
	}
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	
	@Override
	public CardInfo clone(){
		CardInfo card = new CardInfo();
		card.setCardNo(this.getCardNo());
		card.setCompany(this.getCompany());
		card.setCreateDate(this.getCreateDate());
		card.setIdentity(this.getIdentity());
		card.setMobile(this.getMobile());
		card.setName(this.getName());
		card.setStatus(this.getStatus());
		return card;
	}
}
