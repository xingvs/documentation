package com.xy;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.velocity.VelocityConfigurer;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.dili.titan.common.utils.web.DemoDataGen;
import com.dili.titan.common.utils.web.Page;
import com.dili.titan.common.utils.web.WebUtils;
import com.domain.CardInfo;

@Controller
@RequestMapping(value = "/")
public class TestController {

	@Autowired
	private VelocityConfigurer velocityConfigurer;
	
	public TestController(){
		System.out.println("controller inited");
	}
	
	@Autowired
	WebUtils webUtils;
	
	@RequestMapping(value = "/table_manage", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView tableManage(String currentPage, String res2, Model view)
			throws Exception {
		ModelAndView model = new ModelAndView("card_demo"); 
		Integer cur = StringUtils.isBlank(currentPage) ? 1 : Integer.parseInt(currentPage);
		Page page = new Page();
		page.setCurrentPage(cur);
		page.setTotalCount(DemoDataGen.totalCount());
		page.setPageSize(20);
		
		model.addObject("page", page);
		model.addObject("webUtils", webUtils);
		model.addObject("list", DemoDataGen.getInfoList(20, cur));
		return model;
	}
	
	@RequestMapping(value = "/table_manage_ajax", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView tableManageAjax(String currentPage, String res2, Model view)
			throws Exception {
		ModelAndView model = new ModelAndView("card_ajax_demo"); 
		Integer cur = StringUtils.isBlank(currentPage) ? 1 : Integer.parseInt(currentPage);
		Page page = new Page();
		page.setCurrentPage(cur);
		page.setTotalCount(DemoDataGen.totalCount());
		page.setPageSize(20);
		
		model.addObject("page", page);
		model.addObject("webUtils", webUtils);
		model.addObject("list", DemoDataGen.getInfoList(20, cur));
		return model;
	}
	
	
	@RequestMapping(value = "/table_list", method = { RequestMethod.GET, RequestMethod.POST })
	@ResponseBody
	public String tableList(Integer currentPage, Integer pageSize)
			throws Exception {
		Integer cur = currentPage == null ? 1 : currentPage;
		Integer size = pageSize == null ? 20 : pageSize;
		
		
		List<CardInfo> list = DemoDataGen.getInfoList(size, cur);
		
		JSONObject json = new JSONObject();
		JSONArray array = new JSONArray();
		
		for(CardInfo info : list){
			JSONObject temp = new JSONObject();
			temp.put("cardNo", info.getCardNo());
			temp.put("company", info.getCompany());
			temp.put("createDate", info.getCreateDate());
			temp.put("identity", info.getIdentity());
			temp.put("mobile", info.getMobile());
			temp.put("name", info.getName());
			temp.put("status", info.getStatus());
			array.add(temp);
		}
		json.put("list", array);
		json.put("totalCount", DemoDataGen.totalCount());
		json.put("currentPage", cur);
		json.put("pageSize", size);
		json.put("success", true);
		return json.toJSONString();
	}
}
