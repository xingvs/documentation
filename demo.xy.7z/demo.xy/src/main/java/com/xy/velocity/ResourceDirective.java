package com.xy.velocity;

import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

import org.apache.velocity.context.InternalContextAdapter;
import org.apache.velocity.exception.MethodInvocationException;
import org.apache.velocity.exception.ParseErrorException;
import org.apache.velocity.exception.ResourceNotFoundException;
import org.apache.velocity.runtime.directive.Directive;
import org.apache.velocity.runtime.parser.node.Node;
import org.apache.velocity.runtime.parser.node.SimpleNode;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.support.RequestContext;

public class ResourceDirective extends Directive{

	@Override
	public String getName() {
		return "dl_auth";
	}

	@Override
	public int getType() {
		return BLOCK;
	}

	@Override
	public boolean render(InternalContextAdapter context, Writer writer,
			Node node) throws IOException, ResourceNotFoundException,
			ParseErrorException, MethodInvocationException {
		
		for(Object s : context.getKeys()){
			System.out.println(s.toString());
		}
		
		RequestContext o = (RequestContext) context.get("springMacroRequestContext");
		
		WebApplicationContext appContext = o.getWebApplicationContext();
		
		SimpleNode sn_resource = (SimpleNode) node.jjtGetChild(0);
		SimpleNode sn_user = (SimpleNode) node.jjtGetChild(1);
		
		String resource = (String) sn_resource.value(context);
		String user = (String) sn_user.value(context);
		Node body = node.jjtGetChild(2); 
		if(("1".equals(user) && "resource1".equals(resource)) || ("2".equals(user) && "resource2".equals(resource))){
			StringWriter sw = new StringWriter();
			body.render(context, sw);
			writer.write(sw.toString());
		}
		return true;
	}

}
