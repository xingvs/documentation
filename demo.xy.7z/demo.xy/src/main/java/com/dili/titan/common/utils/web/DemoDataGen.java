package com.dili.titan.common.utils.web;

import java.util.ArrayList;
import java.util.List;

import com.domain.CardInfo;

public class DemoDataGen {

	public static final List<CardInfo> demoLib = new ArrayList<CardInfo>();
	
	public static void genDemoData () {
		CardInfo base = new CardInfo();
		base.setCompany("中国国际证券公司");
		base.setCreateDate("2015-01-15 15:57:19");
		base.setIdentity("对公");
		base.setMobile("13980809900");
		base.setName("肖羊");
		base.setStatus("正常");
		
		for(int i = 0 ; i < 300 ; i++){
			CardInfo info = base.clone();
			info.setCardNo((long) i);
			demoLib.add(info);
		}
	}
	
	public static List<CardInfo> getInfoList(int pageSize, int currentPage){
		if(demoLib.size() == 0){
			genDemoData();
		}
		int start = pageSize * (currentPage - 1);
		int end = pageSize * currentPage > demoLib.size() ? demoLib.size() : pageSize * currentPage;
		return demoLib.subList(start, end);
	}
	
	public static int totalCount(){
		if(demoLib.size() == 0){
			genDemoData();
		}
		
		return demoLib.size();
	}
}
