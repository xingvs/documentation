package com.dili.titan.common.utils.web;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;

public class WebUtils {

    private String assetsPath;

    /**
     * 获取到资源文件地址
     * 
     * @param file
     * @return
     */
    public String getAssetsPath(String file) {
        return assetsPath + file;
    }

    public List<String[]> getCrumbsByString(String crumbs) {
        if (StringUtils.isEmpty(crumbs)) {
            return null;
        }
        String[] sp = crumbs.split(",");
        List<String[]> list = new ArrayList<String[]>();
        for (String val : sp) {
            String[] url = val.split(":");
            list.add(url);
        }
        return list;
    }

    public void setAssetsPath(String assetsPath) {
        this.assetsPath = assetsPath;
    }

    public int[] pageSplit(int curr, int total, int count) {
        int start = Math.max(1, curr - count / 2);
        int end = Math.min(total, start + count - 1);
        start = Math.max(1, end - count + 1);
        return createSplit(start, end);
    }

    private int[] createSplit(int start, int end) {
        int size = end + 1 - start;
        int[] pages = new int[size];
        for (int i = 0, j = start; i < size; i++, j++) {
            pages[i] = j;
        }
        return pages;
    }
}