//配合分页宏进行页面跳转js方法
function goPage(index){
	var form = $("FORM")[0];
	if(!form){
		form = '<form></form>';
		form = $(form);
	}
	if(form["pageSize"]==null){$(form).append("<input type='hidden' name='pageSize'/>");}
	if(form["currentPage"]==null){$(form).append("<input type='hidden' name='currentPage'/>");}
	form["pageSize"].value = $("#page-pageSize").val();
	form["currentPage"].value = index;
	form['method'] = "post";
	$(form).submit();	
}

/**
 *demo程序初始化页面 
 */
function initXPager(){
	var page = {pageSize : 10, currentPage : 1};
	var done = loadPage(page);
	done.done(function(){
		$('#testPage').xPager($.extend(page, {onChange : testOnchange}));
	});
}

/**
 * demo程序ajax页面加载
 * @param page
 * @returns
 */
function loadPage(page){
	return $.post("table_list", page, function(result){
		if(result && result.success){
			var container = $("table#data-table tbody");
			container.empty();
			$.each(result.list, function(i, n){
				var color = i%2 == 0 ? "even" : "odd";
				var innerRow = 	"<tr class='" + color + "'>" +
        	                    "<td><input type='checkbox'></td>" + 
                                "<td>" + n.cardNo + "</td>" +
                "<td>" + n.identity + "</td>" +
                "<td>" + n.company + "</td>" +
                "<td>" + n.name + "</td>" +
                "<td>" + n.mobile + "</td>" +
                "<td>" + n.createDate + "</td>" +
                "<td>" + n.status + "</td>" +
                "<td>" +
            	"<a href='javascript:;' class='btn btn-primary btn-xs m-r-5'><i class='fa fa-eye'></i> 查看</a>" +
                "<a href='javascript:;' class='btn btn-success btn-xs m-r-5'><i class='fa fa-edit'></i> 编辑</a>" +
                "<a href='javascript:;' class='btn btn-danger btn-xs  m-r-5'><i class='fa fa-trash-o'></i> 删除</a>" +
                "</td>" +
                "</tr>";
				container.append($(innerRow));
			});
			
			page.totalCount = result.totalCount;
			page.currentPage = result.currentPage;
			page.pageSize = result.pageSize;
		}
	}, "json");
}

/**
 * demo程序刷新页面
 * @param page
 * @returns {Boolean}
 */
function testOnchange(page){
	loadPage(page);
	return true;
}

/**
 * ajax分页插件
 * 使用方式：
 * $('#testPage').xPager(options);
 * 
 * options说明，见 $.fn.xPager.defaults
 * 
 * 其中onChange是回调函数，用于页面跳转事件触发后向
 * 服务端请求数据和渲染页面，页面跳转事件触发后向
 * onChange函数传递的参数格式为：
 * 
 * {
 * pageSize : 20, 分页大小
 * currentPage : 5, 当前页
 * }
 * 
 * 回调函数必须有boolean型返回值代表此次页面刷新成功
 * 
 * */
(function($) {
	$.fn.xPager = function(options) {
		var opts = $.extend({}, $.fn.xPager.defaults, options);
		return this.each(function() {
			$this = $(this);
			var o = $.meta ? $.extend({}, opts, $this.data()) : opts;
			var currentPage = o.start;
			var tc = o.totalCount;
			var ps = o.pageSize;
			o.totalPage = tc%ps == 0 ? tc/ps : tc/ps + 1;
			
			$.fn.draw(o,$this,currentPage);	
		});
	};
	
	//分页插件默认参数
	$.fn.xPager.defaults = {
		totalCount 	: 0,  //总条数，需服务端返回
		pageSize    : 20, //一页显示条数
		totalPage   : 1,  //总页数，需服务端返回总条数后计算
		start 		: 1,  //起始页码
		display  	: 6,  //一次展示页数
		onChange	: function(){return false;},
	};
	$.fn.draw = function(o, obj, selectedPage){
		var currentPage = selectedPage ? selectedPage : 1;
		var params = {
			pageSize : o.pageSize,
			currentPage : currentPage,
		};
		$this.empty();

		var _previous = $(document.createElement('a')).addClass('paginate_button previous').html('上一页');
		if(selectedPage == 1){
			_previous.addClass('disabled');
		}
		var _pageSpan = $(document.createElement('span'));
		
		var _divwrapleft	= $(document.createElement('div')).addClass('dataTables_paginate paging_simple_numbers');
		_divwrapleft.append(_previous);
		_divwrapleft.append(_pageSpan);
		
		var pageRange = $.fn.xPager.calcPage(selectedPage, o.totalPage, o.display);
		
		//绘制页码
		for(var i = pageRange.start; i <= pageRange.end; i++){
			var val = i;
			var _tempPage = $(document.createElement('a')).addClass('paginate_button').html(val + "");
			_tempPage.attr("id", "page" + val);
			if(i == currentPage){
				_tempPage.addClass("disabled current");
			}
			//绑定页码点击事件
			_tempPage.bind('click', function(e){
				var self = $(this);
				var currentPage = parseInt(self.html());
				if(!self.hasClass("current")){
					$.each($this.find(".paginate_button"), function(i, n){
						$(n).removeClass("current disabled");
					});
					self.addClass("disabled current");
					params.currentPage = currentPage;
					if(o.onChange(params)){
						$.fn.draw(o, obj, currentPage);
					}
				}
			});
			_pageSpan.append(_tempPage);
		}
		
		var _next = $(document.createElement('a')).addClass('paginate_button next').html('下一页');
		if(selectedPage >= o.totalPage){
			_next.addClass('disabled');
		}
		_divwrapleft.append(_next);
		$this.append(_divwrapleft);
		//点击上一页
		_previous.click(function(e){
			var self = $(this);
			if(!self.hasClass("disabled")){
				params.currentPage = selectedPage - 1;
				if(o.onChange(params)){
					$.fn.draw(o, obj, selectedPage - 1);
				}
			}
		});
		//点击下一页
		_next.click(function(e){
			var self = $(this);
			if(!self.hasClass("disabled")){
				params.currentPage = selectedPage + 1;
				if(o.onChange(params)){
					$.fn.draw(o, obj, selectedPage + 1);
				}
			}
		});
		
		//下拉菜单直接跳转页面dom生成
		var selectDiv	= $(document.createElement('div')).addClass('dataTables_length pull-right');
		var leftLabel = $(document.createElement('span')).html('跳转到第');
		var rightLabel = $(document.createElement('span')).html('页');
		
		var selectLabel = $(document.createElement('label'));
		var selectPager = $(document.createElement('select'));
		
		selectDiv.append(selectLabel);
		selectLabel.append(leftLabel);
		selectLabel.append(selectPager);
		selectLabel.append(rightLabel);
		_divwrapleft.before(selectDiv);
		
		//option dom生成
		for(i = 1 ; i <= o.totalPage; i++){
			var _tempOption = $(document.createElement("option")).val(i).html(i + "");
			if(i == currentPage){
				_tempOption.attr("selected", "true");
			}
			selectPager.append(_tempOption);
		}

		//下拉菜单选择事件
		selectPager.bind("change", function(){
			var self = $(this);
			params.currentPage = self.find("option:selected").val();
			if(o.onChange(params)){
				$.fn.draw(o, obj, params.currentPage);
			}
		});
	};
	
	/**
	 * @Param curr 当前页码
	 * @Param total 总页码
	 * @Param totalCount 展示页码
	 * */
	$.fn.xPager.calcPage = function(curr, total, count) {
        start = Math.max(1, curr - count / 2);
        end = Math.min(total, start + count - 1);
        start = Math.max(1, end - count + 1);
        return {start : parseInt(start), end : parseInt(end)};
	};
	
})(jQuery);